module.exports = {
  prefix: process.env.BOT_PREFIX || "!",
  owner: process.env.OWNER_NUMBER,
  mongoUri: process.env.MONGODB_URI
};